AutoImageStitch
===============

This project is the source code of my thesis for master's degree. For more information, source code or experiment datasets, mail me via zhuzewei0927@gmail.com.
